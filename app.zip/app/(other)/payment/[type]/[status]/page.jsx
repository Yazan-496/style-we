import StatusPayment from "components/Pages/Payments";

const PageDesktop = () => {
    return <StatusPayment />;
};

export default PageDesktop;
