import FlashSaleDesktop from 'components/Pages/AllFlashDeals';

const PageDesktop = () => {
    return <FlashSaleDesktop />;
};

export default PageDesktop;
