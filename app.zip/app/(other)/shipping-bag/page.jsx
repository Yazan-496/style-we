import ShippingBag from 'components/Pages/ShippingBag';

const PageDesktop = () => {
    return <ShippingBag />;
};

export default PageDesktop;
