import InitialDesktopHeader from 'components/Account/desktop/initialDesktopHeader';
import React from 'react';


const Loading = () => {
  return (
    <div>
      <InitialDesktopHeader />
    </div>
  );
};

export default Loading;
