import PaymentMethod from "components/Pages/OrdersList";

const PageDesktop = () => {
    return <PaymentMethod />;
};

export default PageDesktop;
