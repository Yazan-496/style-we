import React from 'react';
import PageFooterWithRedux from 'components/Pages/Information';
function MainPageFooter(props) {
  return (
    <PageFooterWithRedux />
  );
}

export default MainPageFooter;