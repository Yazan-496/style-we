export default function Custom404() {
    return <div>desktop 404</div>;
}
