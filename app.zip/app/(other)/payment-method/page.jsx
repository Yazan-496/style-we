import PaymentMethod from 'components/Pages/PaymentMethod';

const PageDesktop = () => {
    return <PaymentMethod />;
};

export default PageDesktop;
