
import ComponentConsole from "./ComponentConsole";

const ConsoleApi = async ( data, type ) => {
       await ComponentConsole(data, type)
       return <></>;
};
export default ConsoleApi;