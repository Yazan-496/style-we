const CanCall = (props) => {
  return <>{props.children}</>;
};

export default CanCall;
