export const _GetMainPageSections = () => ({
  type: "GET_SECTIONS_REDUCERS",
});
