import UnderDev from "components/underdevelop";
export default function Coupon() {
    return (<UnderDev />)
}