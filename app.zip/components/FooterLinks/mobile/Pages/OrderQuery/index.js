import React from "react";
import Body from "./Body";
import Layout from "../../Layout";
const OrderQueryBody = () => {
  return <Body />;
};
export default OrderQueryBody;
