import React from "react";
import Body from "./Body";
import Layout from "../../Layout";
const IntellectualBody = () => {
  return (
    <Layout>
      <Body />
    </Layout>
  );
};
export default IntellectualBody;
