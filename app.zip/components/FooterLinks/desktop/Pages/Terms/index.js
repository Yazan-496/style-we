import React from "react";
import Body from "./Body";
import Layout from "../../Layout";
const TermsBody = () => {
  return (
    <Layout>
      <Body />
    </Layout>
  );
};
export default TermsBody;
