import React from "react";
import Body from "./Body";
import Layout from "../../Layout";
const AboutUs = () => {
  return (
    <Layout>
      <Body />
    </Layout>
  );
};
export default AboutUs;
