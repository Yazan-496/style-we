import React from "react";
import Body from "./Body";
import Layout from "../../Layout";
const SmsTermsBody = () => {
  return (
    <Layout>
      <Body />
    </Layout>
  );
};
export default SmsTermsBody;
