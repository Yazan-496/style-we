import React from "react";
import Body from "./Body";
const OrderQueryBody = () => {
  return <Body />;
};
export default OrderQueryBody;
