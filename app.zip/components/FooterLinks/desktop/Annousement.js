const Annousement = (props) => {
  return (
    <>
      <img
        className="headerphoto"
        src="/image/catalog/activity/1S1PEuyzX91684138371.jpg"
        alt="top banner"
      />
      {/* <Image
          className="media-wrap image-wrap"
          src="/image/catalog/activity/dMOf3EPxXA1648612410.jpg"
          alt="3"
          width="500"
          height="500"
        /> */}
    </>
  );
};

export default Annousement;
