export default function SwiperElement() {
    return (<>
    </>)
}