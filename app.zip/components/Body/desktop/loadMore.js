import Image from "next/legacy/image"

const LoadMore = ({ section }) => {
    return (
        <>

        </>
    )
}

export default LoadMore