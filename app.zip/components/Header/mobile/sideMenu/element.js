export default function SideMenuElement(props) {
    return (
        <></>
    )
}