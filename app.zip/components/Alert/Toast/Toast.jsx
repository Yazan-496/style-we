'use client';
import { Alert } from 'components/Alert/Toast';

const Toast = () => {
    return <Alert />;
};
export default Toast;
